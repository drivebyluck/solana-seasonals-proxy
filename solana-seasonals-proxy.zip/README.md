# Solana Seasonals Proxy Server

This is a proxy server for pulling Solana market data from CoinGecko, hosted on Render.

## Features
- Fetches historical Solana price data
- Avoids CORS issues by routing through this server

## Endpoint
- `/seasonals` returns raw data (you can later format into seasonals on frontend)

## Deploy to Render
1. Create a new web service at [https://dashboard.render.com](https://dashboard.render.com)
2. Connect to your GitHub repo or upload files manually
3. Set build command to `npm install`
4. Set start command to `npm start`